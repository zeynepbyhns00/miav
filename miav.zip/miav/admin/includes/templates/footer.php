<!--<footer>
        <div class="text-center">
            <span>CopyRight &copy; 2020 HOUBET Inc. All Right Reserved with love by Ayman Debzi.</span>
            <ul>
                <li class="fa fa-facebook"></li>
                <li class="fa fa-instagram"></li>
                <li class="fa fa-twitter"></li>
                <li class="fa fa-youtube"></li>
                <li class="fa fa-linkedin"></li>
            </ul>
        </div>   
    </footer>-->		
		<script src="<?php echo $js ?>jquery-1.12.1.min.js"></script>
		<script src="<?php echo $js ?>jquery-ui.min.js"></script>
		<script src="<?php echo $js ?>bootstrap.min.js"></script>
		<script src="<?php echo $js ?>jquery.selectBoxIt.min.js"></script>
		<script src="<?php echo $js ?>backend.js"></script>
	</body>
</html>