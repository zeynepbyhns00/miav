<?php

	function lang($phrase) {

		static $lang = array(

			// Navbar Links

			'HOME_ADMIN' 	=> 'Ana Sayfa',
			'CATEGORIES' 	=> 'Kategoriler',
			'ITEMS' 		=> 'Ürünler',
			'MEMBERS' 		=> 'Üyeler',
			'STATISTICS' 	=> 'Statistics',
			'LOGS' 			=> 'Logs',
			'' => '',
			'' => '',
			'' => '',
			'' => '',
			'' => ''
		);

		return $lang[$phrase];

	}
