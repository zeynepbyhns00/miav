<?php
	ob_start();
	session_start();
	$pageTitle = 'Ana Sayfa';
	include 'init.php';
?>

<div class="container-full">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
      <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="res/ko.webp">
           <h3>Miav</h3>
      </div>

      <div class="item">
        <img src="res/aa.webp">
        <div class="carousel-caption">
        </div>
      </div>

      <div class="item">
        <img src="res/ko.webp">
      </div>
    </div>
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Önceki</span>
  </a>

    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Sonraki</span>
  </a>
  </div>
</div>
<div class="container" style="padding-top:50px;padding-bottom:50px;">
<div class="row">
        <div class="col-md-7 col-md-push-5">
          <h2 class="featurette-heading">Patili Dostlarımız </h2>
          <p class="lead">Patili dostlarımız için sağlıklı ve güvenilir alışverişin adresi Miav.</p>
        </div>
        <div class="col-md-5 col-md-pull-7">
          <img class="featurette-image img-responsive center-block" data-src="holder.js/500x500/auto" alt="500x500" src="res/kop.jpg" data-holder-rendered="true">
        </div>
</div>
</div>
<div style="padding-top:50px;" class="container">
	<div class="row">
		<?php
			$allItems = getAllFrom('*', 'items', 'where Approve = 1', '', 'Item_ID');
			foreach ($allItems as $item) {
				echo '<div class="col-sm-6 col-md-3">';
					echo '<div class="thumbnail item-box">';
						echo '<span class="price-tag">TL' . $item['Price'] . '</span>';
						if (empty($item['picture'])) {
							echo "<img style='width:250px;height:300px' src='admin/uploads/default.png' alt='' />";
						} else {
							echo "<img style='width:250px;height:300px' src='admin/uploads/items/" . $item['picture'] . "' alt='' />";
						}
						echo '<div class="caption">';
							echo '<h3><a href="items.php?itemid='. $item['Item_ID'] .'">' . $item['Name'] .'</a></h3>';
							echo "<p style='overflow-wrap: normal;overflow: hidden;'>". $item['Description'] . '</p>';
						echo '</div>';
					echo '</div>';
				echo '</div>';
			}
		?>
	</div>
</div>

<style>
.carousel .carousel-indicators li {
  background-color: #fff;
  background-color: rgba(70,70,70,.25);
}

.carousel .carousel-indicators .active {
  background-color: #444;
}
h1 {
  margin: 60px auto;
  text-align: center;
}

img {
  width: 100%;
}
</style>
<?php
	include $tpl . 'footer.php'; 
	ob_end_flush();
?>
